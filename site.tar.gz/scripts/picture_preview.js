const divs = document.querySelectorAll('.image');

divs.forEach(el => el.addEventListener('click', event => {
	let source_image = el.getBoundingClientRect();
	
	let preview_image = document.createElement('img');
	preview_image.className = 'image_preview';

	preview_image.style.position = 'fixed';
	
	preview_image.style.top = source_image.top + 15 + 'px'; 
	preview_image.style.left = source_image.left + 25 + 'px'; 
	preview_image.src = el.src;
	

	document.body.append(preview_image);
/*
	preview_image.style.top = '50%';
	preview_image.style.right = '0';
	preview_image.style.left = '50%';
	preview_image.style.bottom = '0';
	
	preview_image.style.height = '85%';
	preview_image.style.width = '85%';
	preview_image.style.transform = 'translate(-50%, -50%)';
	*/	
	setTimeout(() => anime ({
		targets: '.image_preview',
		translateX: [0, "-50%"],
		translateY:	[0, "-50%"], 
		width: ["30%", "85%"],
		height: ["300px", "800px"],
		top: "50%",
		left: "50%",
		easing: 'spring(1, 80, 10, 0)',
		duration: 500
	}), 1000);
	console.log(source_image.top + window.pageYOffset);
	console.log(el.src);
}));
